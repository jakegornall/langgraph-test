import React from 'react';
import './UsageDashboard.css';

interface UsageStatsProps {
  label: string;
  value: number;
}

export const UsageStats: React.FC<UsageStatsProps> = ({ label, value }) => {
  return (
    <div className="usage-stats">
      <h2 className="usage-stats__label">{label}</h2>
      <div className="usage-stats__value">{value}</div>
    </div>
  );
};
