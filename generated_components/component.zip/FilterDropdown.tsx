import React from 'react';
import './UsageDashboard.css';

interface FilterDropdownProps {
  label: string;
  options: string[];
}

export const FilterDropdown: React.FC<FilterDropdownProps> = ({ label, options }) => {
  return (
    <div className="filter-dropdown">
      <button className="filter-dropdown__button">
        {label}
        <span className="filter-dropdown__arrow">▼</span>
      </button>
    </div>
  );
};
