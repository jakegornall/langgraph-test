import React from 'react';
import { UsageDashboard } from './UsageDashboard';

const exampleData = {
  workspaces: ['Workspace 1', 'Workspace 2'],
  apiKeys: ['Key 1', 'Key 2'],
  models: ['Model 1', 'Model 2'],
  currentDate: 'Jan 2025',
  tokensIn: 33,
  tokensOut: 150,
  dailyUsage: [
    { date: 'Jan 01', usage: 0 },
    { date: 'Jan 04', usage: 0 },
    { date: 'Jan 07', usage: 0 },
    { date: 'Jan 10', usage: 183 },
  ]
};

const App = () => {
  return <UsageDashboard {...exampleData} />;
};

export default App;
