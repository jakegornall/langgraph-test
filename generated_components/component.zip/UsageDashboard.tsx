import React from 'react';
import { FilterDropdown } from './FilterDropdown';
import { UsageStats } from './UsageStats';
import { UsageChart } from './UsageChart';
import './UsageDashboard.css';

interface UsageDashboardProps {
  workspaces: string[];
  apiKeys: string[];
  models: string[];
  currentDate: string;
  tokensIn: number;
  tokensOut: number;
  dailyUsage: Array<{
    date: string;
    usage: number;
  }>;
}

export const UsageDashboard: React.FC<UsageDashboardProps> = ({
  workspaces,
  apiKeys,
  models,
  currentDate,
  tokensIn,
  tokensOut,
  dailyUsage
}) => {
  return (
    <div className="usage-dashboard">
      <h1 className="usage-dashboard__title">Usage</h1>
      
      <div className="usage-dashboard__filters">
        <FilterDropdown label="All Workspaces" options={workspaces} />
        <FilterDropdown label="All API keys" options={apiKeys} />
        <FilterDropdown label="All Models" options={models} />
        
        <div className="usage-dashboard__date-nav">
          <button className="usage-dashboard__nav-btn">&lt;</button>
          <span className="usage-dashboard__current-date">{currentDate}</span>
          <button className="usage-dashboard__nav-btn">&gt;</button>
        </div>
        
        <FilterDropdown label="Group by: None" options={['None', 'Daily', 'Weekly']} />
        
        <button className="usage-dashboard__export-btn">
          <span className="usage-dashboard__export-icon">↗</span>
          Export
        </button>
      </div>

      <div className="usage-dashboard__stats">
        <UsageStats label="Total tokens in" value={tokensIn} />
        <UsageStats label="Total tokens out" value={tokensOut} />
      </div>

      <UsageChart data={dailyUsage} />
    </div>
  );
};
