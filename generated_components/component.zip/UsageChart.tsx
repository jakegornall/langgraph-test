import React from 'react';
import './UsageDashboard.css';

interface UsageChartProps {
  data: Array<{
    date: string;
    usage: number;
  }>;
}

export const UsageChart: React.FC<UsageChartProps> = ({ data }) => {
  const maxUsage = Math.max(...data.map(d => d.usage));
  
  return (
    <div className="usage-chart">
      <h2 className="usage-chart__title">Daily token usage</h2>
      <p className="usage-chart__subtitle">Includes usage from both API and Console</p>
      
      <div className="usage-chart__container">
        <div className="usage-chart__y-axis">
          {[0, 50, 100, 150, 200].map(value => (
            <div key={value} className="usage-chart__y-label">{value}</div>
          ))}
        </div>
        
        <div className="usage-chart__bars">
          {data.map((item, index) => (
            <div key={index} className="usage-chart__bar-container">
              <div 
                className="usage-chart__bar"
                style={{ 
                  height: `${(item.usage / maxUsage) * 100}%`,
                  backgroundColor: '#B85C38'
                }}
              />
              <div className="usage-chart__x-label">{item.date}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
